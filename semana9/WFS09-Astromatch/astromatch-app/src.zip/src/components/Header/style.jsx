import styled from 'styled-components'

export const Container = styled.div`
    width: 100%;
    border-bottom: 1px solid lightgrey;
    text-align: center;
`