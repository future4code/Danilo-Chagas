import React from "react"
import {Container} from './style'

function Header () {
    return (
        <Container>
            <h1>Header</h1>
        </Container>
    )
}

export default Header