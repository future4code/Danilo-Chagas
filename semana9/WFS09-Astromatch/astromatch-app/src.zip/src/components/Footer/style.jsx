import styled from 'styled-components'

export const Container = styled.div`
    width: 100%;
    border-top: 1px solid lightgrey;
    text-align: center;
`