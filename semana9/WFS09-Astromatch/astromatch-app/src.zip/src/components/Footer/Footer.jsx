import React from "react"
import {Container} from './style'

function Footer () {
    return <Container><h1>Footer</h1></Container>
}

export default Footer